"""Supply Chain & Inventory Optimization (simulation)
Simulates 365 days of demand for 8 SKUs with variable supplier lead times,
compares a baseline reorder policy against an EOQ + safety-stock policy,
stores daily records in SQLite and analyses them with SQL/Pandas.
All data is SYNTHETIC (assumed demand, cost and lead-time parameters)."""
import sqlite3, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng_master = np.random.default_rng(42)
DAYS, N_SKU, Z = 365, 8, 1.645          # 95% target service level
sku = pd.DataFrame({
    "sku_id": [f"SKU{i+1}" for i in range(N_SKU)],
    "mean_demand": rng_master.integers(20, 120, N_SKU),   # units/day
    "unit_cost": rng_master.integers(50, 400, N_SKU),     # INR
    "lt_mean": rng_master.integers(4, 9, N_SKU),          # days
})
sku["lt_sd"] = 1.5
sku["demand_sd"] = (sku.mean_demand * 0.3).round(1)
HOLD_RATE, ORDER_COST = 0.20 / 365, 500   # 20%/yr holding, INR 500 per order

def policy(row, kind):
    if kind == "baseline":   # naive: order 14 days of demand when stock hits 7 days
        return 7 * row.mean_demand, 14 * row.mean_demand
    d, h = row.mean_demand, row.unit_cost * HOLD_RATE
    eoq = np.sqrt(2 * d * ORDER_COST / h)
    ss = Z * np.sqrt(row.lt_mean * row.demand_sd**2 + (d * row.lt_sd) ** 2)
    return d * row.lt_mean + ss, eoq

def simulate(kind, seed=7):
    rows = []
    for _, r in sku.iterrows():
        rng = np.random.default_rng(seed + int(r.mean_demand))
        rop, q = policy(r, kind)
        stock, pipeline = rop + q, []          # pipeline: (arrival_day, qty)
        for day in range(DAYS):
            stock += sum(a for t, a in pipeline if t == day)
            pipeline = [(t, a) for t, a in pipeline if t > day]
            dem = max(0, int(rng.normal(r.mean_demand, r.demand_sd)))
            sold = min(stock, dem); stock -= sold
            ordered = 0
            if stock + sum(a for _, a in pipeline) <= rop:
                lt = max(1, int(round(rng.normal(r.lt_mean, r.lt_sd))))
                pipeline.append((day + lt, q)); ordered = 1
            rows.append((kind, r.sku_id, day, dem, sold, dem - sold, stock, ordered,
                         stock * r.unit_cost * HOLD_RATE))
    return pd.DataFrame(rows, columns=["policy", "sku_id", "day", "demand", "sold",
                                       "stockout_units", "end_stock", "orders", "holding_cost"])

df = pd.concat([simulate("baseline"), simulate("optimized")])
con = sqlite3.connect(":memory:"); df.to_sql("daily", con, index=False)
summary = pd.read_sql("""
  SELECT policy,
         ROUND(SUM(holding_cost)) AS holding_cost_inr,
         SUM(orders) AS orders_placed,
         SUM(stockout_units) AS lost_units,
         ROUND(100.0 * SUM(sold) / SUM(demand), 2) AS fill_rate_pct,
         ROUND(AVG(end_stock), 1) AS avg_stock_units
  FROM daily GROUP BY policy""", con)
print(summary.to_string(index=False))
b, o = summary.set_index("policy").loc["baseline"], summary.set_index("policy").loc["optimized"]
print(f"\nHolding cost change: {100*(o.holding_cost_inr-b.holding_cost_inr)/b.holding_cost_inr:.1f}%")
print(f"Orders change: {100*(o.orders_placed-b.orders_placed)/b.orders_placed:.1f}%")
print("Fill rate: %.2f%% -> %.2f%%" % (b.fill_rate_pct, o.fill_rate_pct))

# bottleneck SKUs: most stockout units under baseline
print("\nTop stock-out SKUs (baseline):")
print(pd.read_sql("""SELECT sku_id, SUM(stockout_units) lost_units FROM daily
  WHERE policy='baseline' GROUP BY sku_id ORDER BY lost_units DESC LIMIT 3""", con).to_string(index=False))

fig, ax = plt.subplots(1, 2, figsize=(10, 4))
ax[0].bar(summary.policy, summary.holding_cost_inr, color=["#999", "#1f77b4"]); ax[0].set_title("Holding cost (INR, simulated)")
ax[1].bar(summary.policy, summary.fill_rate_pct, color=["#999", "#1f77b4"]); ax[1].set_title("Fill rate (%)"); ax[1].set_ylim(80, 100)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/inventory_results.png", dpi=150)
