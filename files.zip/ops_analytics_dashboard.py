"""Sales & Delivery Operations Analytics Dashboard (synthetic data)
Generates 50,000 synthetic e-commerce orders, loads them into SQLite, runs SQL
(window functions, CTEs) + Pandas analysis, and renders a KPI dashboard.
All data is SYNTHETIC; distributions and effects are assumed."""
import sqlite3, numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(11)
N = 50_000
w = np.ones(365); w[[45, 200, 310]] = 4.0            # assumed 3 flash-sale days
dates = pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.choice(365, N, p=w/w.sum()), "D")
region = rng.choice(["North", "South", "East", "West", "Central"], N, p=[.25, .22, .15, .25, .13])
carrier = rng.choice(["CarrierA", "CarrierB", "CarrierC"], N, p=[.45, .35, .20])
sku = rng.zipf(1.35, N) % 200                         # skewed SKU popularity
price = (50 + (sku * 7919 % 400)).astype(float)
qty = rng.integers(1, 5, N)
promised = rng.integers(3, 7, N)
delay = rng.normal(-0.7, 1.0, N) + np.where(carrier == "CarrierC", 0.9, 0) \
        + np.where(region == "East", 0.6, 0) + np.where(pd.Series(dates).dt.month.isin([11, 12]), 0.7, 0)
actual = np.maximum(1, np.round(promised + delay)).astype(int)
returned = rng.random(N) < (0.04 + 0.03 * (actual > promised))
df = pd.DataFrame(dict(order_date=dates.strftime("%Y-%m-%d"), region=region, carrier=carrier,
    sku=[f"S{s:03d}" for s in sku], revenue=price * qty, promised_days=promised,
    actual_days=actual, returned=returned.astype(int)))
df["on_time"] = (df.actual_days <= df.promised_days).astype(int)
con = sqlite3.connect(":memory:"); df.to_sql("orders", con, index=False)
q = lambda s: pd.read_sql(s, con)

kpi = q("""SELECT COUNT(*) orders, ROUND(SUM(revenue)) revenue,
  ROUND(100.0*AVG(on_time),1) on_time_pct, ROUND(100.0*AVG(returned),1) return_pct FROM orders""").iloc[0]
monthly = q("""WITH m AS (SELECT substr(order_date,1,7) month, SUM(revenue) rev FROM orders GROUP BY 1)
  SELECT month, rev, ROUND(100.0*(rev-LAG(rev) OVER (ORDER BY month))/LAG(rev) OVER (ORDER BY month),1) mom_pct FROM m""")
carr = q("SELECT carrier, ROUND(100.0*AVG(on_time),1) otp FROM orders GROUP BY carrier ORDER BY otp")
reg = q("SELECT region, ROUND(100.0*AVG(on_time),1) otp FROM orders GROUP BY region ORDER BY otp")
pareto = q("""WITH s AS (SELECT sku, SUM(revenue) rev FROM orders GROUP BY sku),
  r AS (SELECT sku, rev, SUM(rev) OVER (ORDER BY rev DESC) cum, SUM(rev) OVER () tot,
        ROW_NUMBER() OVER (ORDER BY rev DESC) rn, COUNT(*) OVER () n FROM s)
  SELECT sku, rn, n, 100.0*cum/tot cum_pct FROM r ORDER BY rn""")
daily = q("SELECT order_date d, COUNT(*) n FROM orders GROUP BY d").assign(d=lambda x: pd.to_datetime(x.d)).sort_values("d")
daily["z"] = (daily.n - daily.n.rolling(30, min_periods=10).mean()) / daily.n.rolling(30, min_periods=10).std()
anom = int((daily.z.abs() > 3).sum())
n80 = int(pareto[pareto.cum_pct >= 80].rn.min())

print(kpi.to_dict()); print(carr.to_string(index=False)); print(reg.to_string(index=False))
print(f"SKUs generating 80% of revenue: {n80} of {int(pareto.n.iloc[0])} ({100*n80/pareto.n.iloc[0]:.0f}%)")
print(f"Daily order-volume anomalies (|z|>3, 30-day rolling): {anom}")
print("Peak vs trough month:", monthly.loc[monthly.rev.idxmax(), "month"], monthly.loc[monthly.rev.idxmin(), "month"])
nd = df[df.order_date.str[5:7].isin(["11","12"])].on_time.mean(); ot = df[~df.order_date.str[5:7].isin(["11","12"])].on_time.mean()
print(f"On-time Nov-Dec {100*nd:.1f}% vs rest {100*ot:.1f}%")
late = df[df.on_time==0].returned.mean(); ont = df[df.on_time==1].returned.mean()
print(f"Return rate late {100*late:.1f}% vs on-time {100*ont:.1f}%")

fig, ax = plt.subplots(2, 3, figsize=(15, 8)); fig.suptitle(
  f"Ops Analytics Dashboard (synthetic) | Orders {int(kpi.orders):,} | Revenue INR {kpi.revenue/1e6:.1f}M | On-time {kpi.on_time_pct}% | Returns {kpi.return_pct}%", fontsize=12)
ax[0,0].plot(monthly.month, monthly.rev/1e6, marker="o"); ax[0,0].set_title("Monthly revenue (INR M)"); ax[0,0].tick_params(axis="x", rotation=60)
ax[0,1].bar(carr.carrier, carr.otp); ax[0,1].set_title("On-time % by carrier"); ax[0,1].set_ylim(50, 100)
ax[0,2].bar(reg.region, reg.otp, color="tab:orange"); ax[0,2].set_title("On-time % by region"); ax[0,2].set_ylim(50, 100)
ax[1,0].plot(pareto.rn, pareto.cum_pct); ax[1,0].axhline(80, ls="--", c="grey"); ax[1,0].set_title("Pareto: cumulative revenue % vs SKU rank")
ax[1,1].plot(daily.d, daily.n, lw=.7); a = daily[daily.z.abs() > 3]; ax[1,1].scatter(a.d, a.n, c="red", s=15); ax[1,1].set_title("Daily orders (red = anomalies)")
ax[1,2].bar(["On-time", "Late"], [100*ont, 100*late], color=["tab:green", "tab:red"]); ax[1,2].set_title("Return rate %: on-time vs late")
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/ops_dashboard.png", dpi=130)
