"""Event Resource Allocation & Queue Simulation (check-in desks)
Simulates participant check-in at a fest-style event over a 12-hour day with
peak-hour arrival waves. Compares a flat staffing plan against a demand-based
shift plan using the SAME total desk-hours. All inputs are ASSUMED (synthetic)."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RATE = np.array([20, 30, 60, 110, 120, 80, 50, 40, 40, 30, 15, 5])  # arrivals/hour (assumed)
SERVICE_MIN = 4.0                       # mean check-in time per participant (assumed)
FLAT = np.full(12, 4)                   # 4 desks all day -> 48 desk-hours
TOTAL = FLAT.sum()

def demand_plan(total):
    raw = RATE / RATE.sum() * total
    plan = np.maximum(1, np.floor(raw)).astype(int)
    while plan.sum() < total: plan[np.argmax(raw - plan)] += 1
    while plan.sum() > total: plan[np.argmax(plan - raw)] -= 1
    return plan
DYN = demand_plan(TOTAL)

def run(plan, rng):
    arr = np.concatenate([h * 60 + np.sort(rng.uniform(0, 60, rng.poisson(r))) for h, r in enumerate(RATE)])
    free = np.zeros(plan.max()); waits = []
    for a in arr:
        t = a
        while True:
            h = min(int(t // 60), 11); c = plan[h]
            avail = [k for k in range(c) if free[k] <= t]
            if avail: k = avail[0]; break
            t = min(min(free[:c]), (h + 1) * 60) if h < 11 else min(free[:c])
        free[k] = t + rng.exponential(SERVICE_MIN)
        waits.append(t - a)
    return np.array(waits)

rows = {}
for name, plan in [("Flat (4 desks all day)", FLAT), ("Demand-based shifts", DYN)]:
    w = np.concatenate([run(plan, np.random.default_rng(s)) for s in range(300)])
    rows[name] = dict(desk_hours=plan.sum(), avg_wait_min=w.mean(), p95_wait_min=np.percentile(w, 95),
                      pct_wait_over_15=100 * (w > 15).mean())
res = pd.DataFrame(rows).T.round(2)
print("Demand-based plan by hour:", DYN.tolist()); print(res.to_string())
a, b = res.iloc[0], res.iloc[1]
print(f"\nAvg wait change: {100*(b.avg_wait_min-a.avg_wait_min)/a.avg_wait_min:.1f}%")
print(f"P95 wait change: {100*(b.p95_wait_min-a.p95_wait_min)/a.p95_wait_min:.1f}%")
fig, ax = plt.subplots(figsize=(7, 3.5))
ax.bar(np.arange(12) - 0.2, FLAT, 0.4, label="Flat"); ax.bar(np.arange(12) + 0.2, DYN, 0.4, label="Demand-based")
ax.set_xlabel("Hour of day"); ax.set_ylabel("Desks"); ax.legend(); plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/queue_staffing_plan.png", dpi=150)
